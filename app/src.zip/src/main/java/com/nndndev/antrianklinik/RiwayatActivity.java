package com.nndndev.antrianklinik;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * RiwayatActivity — Menampilkan riwayat antrian pasien dengan filter dan pencarian.
 */
public class RiwayatActivity extends AppCompatActivity {

    private RecyclerView rvRiwayat;
    private Spinner spinnerFilter, spinnerWaktu;
    private TextView tvTotalRiwayat, tvEmpty;
    private SearchView searchView;
    private Button btnExport;
    private BottomNavigationView bottomNavigationView;

    private PasienAdapter pasienAdapter;
    private List<Pasien> daftarRiwayat;
    private List<Pasien> daftarRiwayatFiltered;

    private DatabaseHelper databaseHelper;

    private static final String[] FILTER_STATUS = {
        "Semua Status", "Menunggu", "Sedang Dilayani", "Selesai", "Dibatalkan"
    };

    private static final String[] FILTER_WAKTU = {
        "Semua Waktu", "Hari Ini", "Bulan Ini", "Tahun Ini"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Riwayat Antrian");
        }

        databaseHelper = new DatabaseHelper(this);
        daftarRiwayatFiltered = new ArrayList<>();

        bindViews();
        setupFilterSpinner();
        setupRecyclerView();
        setupSearchView();
        setupBottomNav();
        
        loadRiwayat();
    }

    private void bindViews() {
        rvRiwayat       = findViewById(R.id.rv_riwayat);
        spinnerFilter   = findViewById(R.id.spinner_filter);
        spinnerWaktu    = findViewById(R.id.spinner_waktu);
        tvTotalRiwayat  = findViewById(R.id.tv_total_riwayat);
        tvEmpty         = findViewById(R.id.tv_empty);
        searchView      = findViewById(R.id.search_view);
        btnExport       = findViewById(R.id.btn_export_csv);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        btnExport.setOnClickListener(v -> exportToCSV());
    }

    private void setupBottomNav() {
        bottomNavigationView.setSelectedItemId(R.id.nav_history);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) {
                finish();
                overridePendingTransition(0, 0);
                return true;
            }
            return true;
        });
    }

    private void setupFilterSpinner() {
        // adapter status
        ArrayAdapter<String> adapterStatus = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, FILTER_STATUS);
        adapterStatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFilter.setAdapter(adapterStatus);

        // adapter waktu
        ArrayAdapter<String> adapterWaktu = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, FILTER_WAKTU);
        adapterWaktu.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerWaktu.setAdapter(adapterWaktu);

        AdapterView.OnItemSelectedListener trigger = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                loadRiwayat();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        spinnerFilter.setOnItemSelectedListener(trigger);
        spinnerWaktu.setOnItemSelectedListener(trigger);
    }

    private void setupRecyclerView() {
        pasienAdapter = new PasienAdapter(this, daftarRiwayatFiltered);
        rvRiwayat.setLayoutManager(new LinearLayoutManager(this));
        rvRiwayat.setAdapter(pasienAdapter);

        pasienAdapter.setOnItemClickListener((pasien, position) -> showDetailPasien(pasien));

        // long click untuk hapus
        pasienAdapter.setOnItemLongClickListener((pasien, position) -> {
            showDeleteConfirmDialog(pasien);
            return true;
        });
    }

    private void showDeleteConfirmDialog(Pasien p) {
        new AlertDialog.Builder(this)
            .setTitle("Hapus Riwayat")
            .setMessage("Hapus data " + p.getNama() + " dari riwayat?")
            .setPositiveButton("Hapus", (d, w) -> {
                databaseHelper.deletePasien(p.getId());
                loadRiwayat();
                Toast.makeText(this, "Data dihapus", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Batal", null)
            .show();
    }

    private void setupSearchView() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterByName(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterByName(newText);
                return true;
            }
        });
    }

    /**
     * Load data riwayat dari database dengan filter status dan waktu.
     */
    private void loadRiwayat() {
        String status = spinnerFilter.getSelectedItem().toString();
        String waktu = spinnerWaktu.getSelectedItem().toString();
        
        // konversi "Semua Waktu" ke null sesuai signature DB
        String timeArg = waktu.equals("Semua Waktu") ? null : waktu;
        
        daftarRiwayat = databaseHelper.getPasienFiltered(status, timeArg);
        
        // reset pencarian saat ganti filter
        searchView.setQuery("", false);
        filterByName("");
    }

    /**
     * Filter list berdasarkan input nama (real-time).
     */
    private void filterByName(String query) {
        daftarRiwayatFiltered.clear();
        if (query.isEmpty()) {
            daftarRiwayatFiltered.addAll(daftarRiwayat);
        } else {
            String q = query.toLowerCase();
            for (Pasien p : daftarRiwayat) {
                if (p.getNama().toLowerCase().contains(q)) {
                    daftarRiwayatFiltered.add(p);
                }
            }
        }
        
        pasienAdapter.updateData(daftarRiwayatFiltered);
        tvTotalRiwayat.setText("Total: " + daftarRiwayatFiltered.size() + " data");
        
        // logic empty state lebih informatif
        if (daftarRiwayat.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Belum ada data riwayat pasien");
        } else if (daftarRiwayatFiltered.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            tvEmpty.setText("Pasien tidak ditemukan");
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    private void showDetailPasien(Pasien p) {
        String detail = "Nama: " + p.getNama() + "\n" +
                        "Umur: " + p.getUmur() + "\n" +
                        "Jenis Kelamin: " + p.getJenisKelamin() + "\n" +
                        "No. Telp: " + p.getNoTelp() + "\n" +
                        "Poli: " + p.getPoli() + "\n" +
                        "Keluhan: " + p.getKeluhan() + "\n" +
                        "Status: " + p.getStatus() + "\n" +
                        "Tanggal: " + p.getTanggalDaftar() + "\n" +
                        "No. Antrian: " + p.getNomorAntrianFormatted();

        new AlertDialog.Builder(this)
            .setTitle("Detail Lengkap Pasien")
            .setMessage(detail)
            .setPositiveButton("Tutup", null)
            .show();
    }

    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.menu_riwayat, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        if (item.getItemId() == R.id.action_export) {
            exportToCSV();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // biar koma dan kutip di dalam teks tidak merusak format CSV
    private String safeCsv(String s) {
        if (s == null) return "";
        return s.replace("\"", "\"\"");
    }

    /**
     * Export data yang sedang tampil ke file CSV di folder Downloads.
     */
    private void exportToCSV() {
        if (daftarRiwayatFiltered.isEmpty()) {
            Toast.makeText(this, "Tidak ada data untuk diekspor", Toast.LENGTH_SHORT).show();
            return;
        }

        // Simpan ke folder Downloads publik
        File downloadFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File file = new File(downloadFolder, "riwayat_antrian_klinik.csv");

        try (FileWriter writer = new FileWriter(file)) {
            // Header
            writer.append("No Antrian,Nama,Umur,Gender,No Telp,Poli,Status,Tanggal\n");
            
            for (Pasien p : daftarRiwayatFiltered) {
                writer.append(p.getNomorAntrianFormatted()).append(",")
                      .append("\"").append(safeCsv(p.getNama())).append("\",")
                      .append(String.valueOf(p.getUmur())).append(",")
                      .append("\"").append(safeCsv(p.getJenisKelamin())).append("\",")
                      .append("\"").append(safeCsv(p.getNoTelp())).append("\",")
                      .append("\"").append(safeCsv(p.getPoli())).append("\",")
                      .append(p.getStatus()).append(",")
                      .append(p.getTanggalDaftar()).append("\n");
            }
            writer.flush();
            
            Toast.makeText(this, "CSV tersimpan di folder Downloads", Toast.LENGTH_SHORT).show();
            bukaFileCSV(file);
            
        } catch (IOException e) {
            Toast.makeText(this, "Gagal simpan CSV: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Buka file CSV menggunakan intent ACTION_VIEW.
     */
    private void bukaFileCSV(File file) {
        Uri path = FileProvider.getUriForFile(this, "com.nndndev.antrianklinik.fileprovider", file);
        
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(path, "text/csv");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        
        try {
            startActivity(Intent.createChooser(intent, "Buka riwayat dengan..."));
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka CSV", Toast.LENGTH_SHORT).show();
        }
    }
}
